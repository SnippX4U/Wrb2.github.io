let nyquil;

function loadimg() {
 nyquil = loadImage("nyquil.jpeg")
  
}

function setup() {
  createCanvas(700, 700);
}

function draw() {
  background(220);
}

function square() {
  
rect
}

